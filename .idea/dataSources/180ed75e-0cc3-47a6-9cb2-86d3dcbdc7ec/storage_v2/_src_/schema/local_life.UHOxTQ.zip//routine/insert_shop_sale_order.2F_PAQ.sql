create procedure insert_shop_sale_order()
  BEGIN
	declare v int;
	declare n int(10);
	declare m bigint(20);
	set v = 1;
	set n = 1800;
	set m = 380515557932999;
	while v < 50
	do
		INSERT INTO `shop_sales_order`
			(`order_id`,
			`number`,
			`shop_id`,
			`partner_company_id`,
			`partner_id`,
			`income`,
			`income_original`,
			`commission_cost`,
			`tech_cost`,
			`partner_cost`,
			`pay_time`,
			`status`,
			`ex_status`,
			`settle_time`,
			`finish_time`,
			`update_time`,
			`create_time`)
		VALUES
			(n, m, 212, 133, 126, 3000*v, 3000*v, 2, 3, 5, '2018-05-10 15:29:57', 4, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2018-05-10 16:45:34', '2018-05-10 15:50:22');

	set n = n+1;
	set m = m+1;
	set v = v+1;
	end while;
END;

