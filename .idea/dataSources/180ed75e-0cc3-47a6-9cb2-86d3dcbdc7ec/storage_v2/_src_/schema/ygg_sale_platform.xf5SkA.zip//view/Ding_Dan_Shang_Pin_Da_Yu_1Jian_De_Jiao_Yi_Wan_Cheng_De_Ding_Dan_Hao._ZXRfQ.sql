create view 订单商品大于1件的交易完成的订单号 as
  select
    `o`.`id`     AS `id`,
    `o`.`number` AS `number`,
    `o`.`type`   AS `type`
  from `ygg_sale_platform`.`order` `o`
  where ((`o`.`status` = 4) and ((select count(`op`.`id`)
                                  from `ygg_sale_platform`.`order_product` `op`
                                  where (`op`.`order_id` = `o`.`id`)) > 1))
  order by `o`.`create_time` desc;

