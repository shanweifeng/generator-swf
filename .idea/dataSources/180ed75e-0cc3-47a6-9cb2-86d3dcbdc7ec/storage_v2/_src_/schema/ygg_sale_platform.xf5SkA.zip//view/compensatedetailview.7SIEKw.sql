create view compensatedetailview as select
                                      `d`.`order_number`           AS `orderNumber`,
                                      `m`.`real_seller_name`       AS `realSellerName`,
                                      `d`.`order_pay_time`         AS `orderPayTime`,
                                      `d`.`collect_logistics_time` AS `collectLogisticsTime`,
                                      `o`.`send_time`              AS `sendTime`,
                                      `d`.`create_time`            AS `createTime`,
                                      `d`.`order_expire_time`      AS `orderExpireTime`,
                                      `d`.`penalty_amount`         AS `penaltyAmount`,
                                      ''                           AS `reason`
                                    from (((`ygg_sale_platform`.`order_delivery_expire` `d`
                                      join `ygg_sale_platform`.`order` `o`
                                        on ((`d`.`order_number` = `o`.`number`))) join `ygg_sale_platform`.`seller` `s`
                                        on ((`d`.`seller_id` = `s`.`id`))) join `ygg_sale_platform`.`seller_main` `m`
                                        on ((`m`.`id` = `s`.`seller_main_id`)))
                                    where (`m`.`ascription` = 1)
                                    union all select
                                                `r`.`order_number`           AS `orderNumber`,
                                                `m`.`real_seller_name`       AS `realSellerName`,
                                                `r`.`order_pay_time`         AS `orderPayTime`,
                                                `d`.`collect_logistics_time` AS `collectLogisticsTime`,
                                                `o`.`send_time`              AS `sendTime`,
                                                `r`.`create_time`            AS `createTime`,
                                                `r`.`order_expire_time`      AS `orderExpireTime`,
                                                `r`.`penalty_amount`         AS `penaltyAmount`,
                                                `r`.`reason`                 AS `reason`
                                              from ((((`ygg_sale_platform`.`order_delivery_exception_record` `r`
                                                join `ygg_sale_platform`.`order` `o`
                                                  on ((`r`.`order_number` = `o`.`number`))) left join
                                                `ygg_sale_platform`.`order_delivery_expire` `d`
                                                  on ((`o`.`number` = `d`.`order_number`))) join
                                                `ygg_sale_platform`.`seller` `s` on ((`r`.`seller_id` = `s`.`id`))) join
                                                `ygg_sale_platform`.`seller_main` `m`
                                                  on ((`m`.`id` = `s`.`seller_main_id`)))
                                              where (`m`.`ascription` = 1);

