create procedure test1()
  BEGIN
-- 需要定义接收游标数据的变量 
  DECLARE t_id int(11);

  -- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;

  -- 游标
  DECLARE cur CURSOR FOR SELECT id FROM mweb_group_account where type !=3;

  -- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  -- 打开游标
  OPEN cur;

-- 开始循环
  read_loop: LOOP
    -- 提取游标里的数据，这里只有一个，多个的话也一样；
    FETCH cur INTO t_id;
    -- 声明结束的时候
    IF done THEN
      LEAVE read_loop;
    END IF;
    -- 这里做你想做的循环的事件

    UPDATE mweb_group_account a set a.unionid=CONCAT(a.unionid,'__weixin') where a.id=t_id;

  END LOOP;
  -- 关闭游标
  CLOSE cur;

END;

